package com.zenin.prank

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.*
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.widget.TextView

/** Только визуал: рисует поверх игры круг FOV и фейковое меню. В игру не вмешивается. */
class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var hud: WebView? = null
    private var menu: WebView? = null
    private var bubble: TextView? = null
    private lateinit var menuLp: WindowManager.LayoutParams
    private val d get() = resources.displayMetrics.density
    private val type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (hud != null) return START_STICKY
        val ch = "zenin"
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(ch, "Zenin", NotificationManager.IMPORTANCE_MIN))
        val n = Notification.Builder(this, ch).setContentTitle("Zenin активен")
            .setSmallIcon(android.R.drawable.ic_menu_view).build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)

        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        // 1) HUD на весь экран, пропускает касания в игру
        hud = web("hud.html").also {
            wm.addView(it, WindowManager.LayoutParams(-1, -1, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT))
        }
        // 2) Меню
        menuLp = WindowManager.LayoutParams((340 * d).toInt(), (300 * d).toInt(), type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = (70 * d).toInt(); y = (20 * d).toInt() }
        menu = web("menu.html").also { wm.addView(it, menuLp) }

        // 3) Кружок «Z»: тап = показать/скрыть меню, тянуть = переместить
        val size = (44 * d).toInt()
        val lp = WindowManager.LayoutParams(size, size, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = (12 * d).toInt(); y = (20 * d).toInt() }
        bubble = TextView(this).apply {
            text = "Z"; gravity = Gravity.CENTER; setTextColor(Color.WHITE); textSize = 20f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor("#ff4d42")) }
            var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
            setOnTouchListener { _, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false }
                    MotionEvent.ACTION_MOVE -> {
                        if (Math.abs(e.rawX - sx) + Math.abs(e.rawY - sy) > 12) moved = true
                        if (moved) { lp.x = ox + (e.rawX - sx).toInt(); lp.y = oy + (e.rawY - sy).toInt(); wm.updateViewLayout(this, lp) }
                    }
                    MotionEvent.ACTION_UP -> if (!moved) menu?.let { it.visibility = if (it.visibility == View.VISIBLE) View.GONE else View.VISIBLE }
                }
                true
            }
        }
        wm.addView(bubble, lp)
        return START_STICKY
    }

    private fun web(file: String) = WebView(this).apply {
        settings.javaScriptEnabled = true
        setBackgroundColor(Color.TRANSPARENT)
        addJavascriptInterface(Bridge(), "Android")
        loadUrl("file:///android_asset/$file")
    }

    inner class Bridge {
        @JavascriptInterface fun hud(js: String) { hud?.post { hud?.evaluateJavascript(js, null) } }
        @JavascriptInterface fun move(dx: Float, dy: Float) {
            menu?.post { menuLp.x += (dx * d).toInt(); menuLp.y += (dy * d).toInt(); wm.updateViewLayout(menu, menuLp) }
        }
        @JavascriptInterface fun hide() { menu?.post { menu?.visibility = View.GONE } }
        @JavascriptInterface fun exit() { stopSelf() }
    }

    override fun onDestroy() {
        listOf<View?>(hud, menu, bubble).forEach { v -> try { if (v != null) wm.removeView(v) } catch (_: Exception) {} }
        super.onDestroy()
    }
}
