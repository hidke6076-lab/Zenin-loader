package com.zenin.prank

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val wv = WebView(this)
        wv.settings.javaScriptEnabled = true
        wv.setBackgroundColor(Color.BLACK)
        wv.addJavascriptInterface(Bridge(), "Android")
        wv.loadUrl("file:///android_asset/loader.html")
        setContentView(wv)
    }

    inner class Bridge {
        @JavascriptInterface fun hasPerm(): Boolean = Settings.canDrawOverlays(this@MainActivity)
        @JavascriptInterface fun askPerm() = runOnUiThread {
            Toast.makeText(this@MainActivity, "Разреши «Поверх других приложений» и вернись назад", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        @JavascriptInterface fun launch() = runOnUiThread {
            if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            startForegroundService(Intent(this@MainActivity, OverlayService::class.java))
            val game = packageManager.getLaunchIntentForPackage("com.axlebolt.standoff2")
            if (game != null) startActivity(game)
            else Toast.makeText(this@MainActivity, "Standoff 2 не установлен", Toast.LENGTH_LONG).show()
        }
    }
}
